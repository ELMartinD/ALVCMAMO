#!/bin/bash
while true
do
 node ../src/index.js
 echo "Restarting server..."
done

# Pause
#pause
